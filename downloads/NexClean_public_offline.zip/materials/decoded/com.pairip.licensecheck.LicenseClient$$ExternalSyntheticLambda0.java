package com.pairip.licensecheck;

/* JADX INFO: compiled from: D8$$SyntheticClass */
/* JADX INFO: loaded from: classes2.dex */
public final /* synthetic */ class LicenseClient$$ExternalSyntheticLambda0 implements Runnable {
    public final /* synthetic */ LicenseClient f$0;

    public /* synthetic */ LicenseClient$$ExternalSyntheticLambda0(LicenseClient licenseClient) {
        this.f$0 = licenseClient;
    }

    @Override // java.lang.Runnable
    public final void run() {
        this.f$0.unbindFromLicensingService();
    }
}