package com.pairip.licensecheck;

import android.content.Context;
import java.util.Objects;

/* JADX INFO: loaded from: classes2.dex */
public final class TrialClient {
    public static void stopTrial(Context context) {
        LicenseClient.stopTrial(context);
    }

    public static int checkTrialStatus(Context context) {
        Objects.requireNonNull(context, "Context must not be null.");
        return LicenseClient.checkTrialStatus().getStatusCode();
    }

    private TrialClient() {
    }
}